# 🛡️ HateShield: AI/ML for Online Safety

This project uses machine learning to detect toxic comments and hate speech in user-generated content. It simulates a lightweight NLP-based classifier for content moderation tools.

## 🚀 Goal
To identify and flag toxic comments using text classification techniques, helping platforms improve community safety.

## 📂 Files Included
- `toxic_comments.csv` – Sample dataset of labeled comments
- `hate_speech_classifier.py` – ML model script using Naive Bayes
- Output: Classification report and sample predictions printed in terminal

## 🧠 Model Details
- **Model:** Multinomial Naive Bayes
- **Vectorization:** CountVectorizer (Bag of Words)
- **Accuracy Measure:** Classification report

## ▶️ How to Run
```bash
python hate_speech_classifier.py
```

## 🧪 Sample Output
```
"You are amazing and smart" => Non-Toxic
"You are pathetic and disgusting" => Toxic
```

## 📦 Libraries Used
- pandas
- sklearn

---
Created by Varun Aditya Madala
