import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import classification_report

# Load dataset
df = pd.read_csv("toxic_comments.csv")

# Text processing
vectorizer = CountVectorizer()
X = vectorizer.fit_transform(df['text'])
y = df['label']

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Train model
model = MultinomialNB()
model.fit(X_train, y_train)

# Evaluate
y_pred = model.predict(X_test)
print("Classification Report:")
print(classification_report(y_test, y_pred))

# Test with custom input
sample = ["You are amazing and smart", "You are pathetic and disgusting"]
sample_vec = vectorizer.transform(sample)
pred = model.predict(sample_vec)
print("\nSample Predictions:")
for text, label in zip(sample, pred):
    print(f'"{text}" => {"Toxic" if label == 1 else "Non-Toxic"}')
