import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report

# Load transaction data
df = pd.read_csv("transactions.csv")

# Create binary target: 1 = flag, 0 = no flag
df['flag'] = ((df['amount'] > 9000) & (df['risk_level'] == 'High')).astype(int)

# Encode categorical variable (location)
df_encoded = pd.get_dummies(df[['amount', 'location']], drop_first=True)

# Add the flag column as target
X = df_encoded
y = df['flag']

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Train a model
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Predict
y_pred = model.predict(X_test)

# Output classification report
print("Model Evaluation:")
print(classification_report(y_test, y_pred))

# Predict on full dataset and export flagged transactions
df['predicted_flag'] = model.predict(df_encoded)
flagged = df[df['predicted_flag'] == 1]
flagged.to_csv("flagged_transactions_ml.csv", index=False)

print("Flagged Transactions (ML-based):")
print(flagged[['transaction_id', 'customer_id', 'amount', 'location', 'risk_level']])
