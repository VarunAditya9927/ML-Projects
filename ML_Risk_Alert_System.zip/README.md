# 🧠 ML-Powered Risk Alert System

This project uses a machine learning model to detect high-risk financial transactions based on transaction amount and customer metadata.

## 📌 Objective
Automatically flag transactions that may indicate potential fraud or require compliance review, using a trained Random Forest classifier.

## 📁 Files Included
- `transactions.csv` – Synthetic dataset of transactions
- `risk_alert_system.py` – Python script that trains a model and flags transactions
- `flagged_transactions_ml.csv` – Output of ML-predicted high-risk transactions

## 🧠 ML Details
- **Model:** Random Forest
- **Features:** Amount, Location (encoded)
- **Target:** Flag if amount > 9000 & risk_level = High

## 📈 Example Output
The model classifies transactions and saves those flagged as high risk in a separate file:
```
transaction_id | amount | location | risk_level | predicted_flag
---------------------------------------------------------------
T1             | 9500   | TX       | High       | 1
T6             | 12000  | TX       | High       | 1
```

## ▶️ How to Run
```bash
python risk_alert_system.py
```

## 🔧 Tools Used
- Python
- Pandas
- Scikit-learn

---
Created by Varun Aditya Madala
